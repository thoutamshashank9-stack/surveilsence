from datetime import datetime
import threading
try:
    from google.cloud import firestore
    import firebase_admin
    from firebase_admin import credentials
except ImportError:
    # Mock classes for testing without GCP dependencies
    class MockFirestore:
        def Client(self): return None
    firestore = MockFirestore()
    class MockFirebase:
        _apps = []
        def initialize_app(self, *args, **kwargs): pass
    firebase_admin = MockFirebase()
    credentials = None

# Thread-local Firestore client (Bug #7 fix)
_db_local = threading.local()

def get_db():
    """Get thread-safe Firestore client"""
    if not hasattr(_db_local, 'db'):
        # In a real run, check if app is initialized. 
        # For mock/local without creds, we might need a mock.
        try:
            if not firebase_admin._apps:
                # Assuming default credentials or specific file
                # cred = credentials.Certificate("service-account.json")
                firebase_admin.initialize_app() 
            _db_local.db = firestore.Client()
        except Exception as e:
            print(f"Warning: Firestore init failed (expected in local mock): {e}")
            _db_local.db = None
    return _db_local.db

def safe_firestore_write(collection, doc_id, data):
    """Write to Firestore with proper type conversion"""
    db = get_db()
    if not db:
        print("Mock: Firestore write skipped (no connection)")
        return

    # Convert all types to Firestore-safe types
    safe_data = {
        'detections': [
            {
                'box': [float(x) for x in det.get('box', [])],  # List of floats
                'class': str(det.get('class', '')),
                'confidence': float(det.get('confidence', 0.0)),
            }
            for det in data.get('detections', [])
        ],
        'timestamp': datetime.now(),  # Firestore handles datetime natively
        'camera_id': str(data.get('camera_id', 'unknown')),
        'frame_count': int(data.get('frame_count', 0)),
    }
    
    db.collection(collection).document(doc_id).set(safe_data)
