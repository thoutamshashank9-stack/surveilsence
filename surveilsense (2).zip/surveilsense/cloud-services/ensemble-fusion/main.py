import sys
import os
import uuid
from flask import request, jsonify

# Adjust path to import base_service
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from base_service import BaseService
except ImportError:
    from cloud_services.base_service import BaseService

try:
    from firestore_handler import safe_firestore_write
except ImportError:
    from cloud_services.ensemble_fusion.firestore_handler import safe_firestore_write

service = BaseService('ensemble-fusion')

@service.app.route('/fuse', methods=['POST'])
@service.error_handler
def fuse():
    data = request.json
    # Logic to fuse detections would go here
    # For now, just pass through or save
    
    doc_id = str(uuid.uuid4())
    safe_firestore_write('detections', doc_id, data)
    
    return jsonify({'status': 'fused', 'id': doc_id})

if __name__ == '__main__':
    service.run()
