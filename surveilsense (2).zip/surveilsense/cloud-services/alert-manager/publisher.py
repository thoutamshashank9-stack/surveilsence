try:
    from google.cloud import pubsub_v1
except ImportError:
    class MockPublisher:
        def PublisherClient(self): return self
        def publish(self, *args, **kwargs):
            class Future:
                def result(self): return "mock_message_id"
            return Future()
    pubsub_v1 = MockPublisher()
import json
import os

def publish_ordered(topic_path, detections, camera_id):
    """Publish messages with ordering key"""
    try:
        publisher = pubsub_v1.PublisherClient()
        
        for i, detection in enumerate(detections):
            message_json = json.dumps({
                'detection': detection,
                'timestamp': detection.get('timestamp'),
                'sequence': i,
                'camera_id': camera_id
            })
            
            # Use camera_id as ordering key
            future = publisher.publish(
                topic_path,
                message_json.encode('utf-8'),
                ordering_key=camera_id  # KEY FIX: ensures per-camera ordering
            )
            
            # Wait for publish to complete
            future.result()
    except Exception as e:
        print(f"Mock: Publisher failed (expected if no creds): {e}")
