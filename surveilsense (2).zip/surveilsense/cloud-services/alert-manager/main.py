import sys
import os
from collections import defaultdict
from datetime import datetime, timedelta
from flask import request, jsonify

# Adjust path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from base_service import BaseService
except ImportError:
    from cloud_services.base_service import BaseService

service = BaseService('alert-manager')

class AlertDeduplicator:
    def __init__(self, window_seconds=5):
        self.window = timedelta(seconds=window_seconds)
        self.recent_alerts = defaultdict(list)
    
    def should_alert(self, detection_id, camera_id):
        """Check if we should send alert for this detection"""
        now = datetime.now()
        key = f"{camera_id}_{detection_id}"
        
        # Clean old alerts
        self.recent_alerts[key] = [
            t for t in self.recent_alerts[key]
            if now - t < self.window
        ]
        
        # Send alert only if none in recent window
        if not self.recent_alerts[key]:
            self.recent_alerts[key].append(now)
            return True
        
        return False

deduplicator = AlertDeduplicator(window_seconds=5)

@service.app.route('/process_alert', methods=['POST'])
@service.error_handler
def process_alert():
    data = request.json
    detections = data.get('detections', [])
    camera_id = data.get('camera_id', 'unknown')
    
    sent_count = 0
    for detection in detections:
        det_id = detection.get('id', 'unknown') # Assuming detection has an ID
        if deduplicator.should_alert(det_id, camera_id):
            # publish_alert(detection) # Logic to publish
            sent_count += 1
            
    return jsonify({'processed': len(detections), 'sent': sent_count})

if __name__ == '__main__':
    service.run()
