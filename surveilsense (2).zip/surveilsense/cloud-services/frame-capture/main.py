import sys
import os
from collections import deque
from flask import request, jsonify

# Adjust path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from base_service import BaseService
except ImportError:
    from cloud_services.base_service import BaseService

service = BaseService('frame-capture')

class FrameBuffer:
    def __init__(self, max_size=30):  # 1 second at 30 FPS
        self.buffer = deque(maxlen=max_size)
    
    def add(self, frame):
        self.buffer.append(frame)  # Auto-discards oldest
    
    def get_recent(self, n=5):
        return list(self.buffer)[-n:]

buffer = FrameBuffer(max_size=30)

@service.app.route('/capture', methods=['POST'])
@service.error_handler
def capture():
    data = request.json
    # In reality we would decode base64, here we just store the mock data
    frame = data.get('frame')
    if frame:
        buffer.add(frame)
    return jsonify({'status': 'captured', 'buffer_size': len(buffer.buffer)})

if __name__ == '__main__':
    service.run()
