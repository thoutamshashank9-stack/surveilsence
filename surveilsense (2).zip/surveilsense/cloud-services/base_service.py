"""
Base service class with health checks and proper env var handling.
All services should inherit from this.
"""

import os
import logging
from functools import wraps
from flask import Flask, jsonify
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BaseService:
    def __init__(self, service_name):
        self.app = Flask(service_name)
        self.service_name = service_name
        self.start_time = datetime.now()
        
        # Load config at runtime (not import time)
        self.config = self._load_config()
        
        # Setup routes
        self._setup_routes()
    
    def _load_config(self):
        """Load configuration from environment variables at runtime"""
        config = {
            'project_id': os.environ.get('GCP_PROJECT_ID'),
            'region': os.environ.get('GOOGLE_CLOUD_REGION', 'us-central1'),
            'port': int(os.environ.get('PORT', 8080)),
            'debug': os.environ.get('DEBUG', 'false').lower() == 'true'
        }
        
        # Validate required vars
        if not config['project_id']:
            logger.warning("⚠️  GCP_PROJECT_ID not set")
        
        return config
    
    def _setup_routes(self):
        """Setup base routes"""
        @self.app.route('/health', methods=['GET'])
        def health_check():
            """Health check endpoint"""
            uptime = (datetime.now() - self.start_time).total_seconds()
            return jsonify({
                'status': 'healthy',
                'service': self.service_name,
                'uptime_seconds': uptime,
                'timestamp': datetime.now().isoformat(),
                'config': {
                    'project_id': self.config['project_id'],
                    'region': self.config['region']
                }
            }), 200
        
        @self.app.route('/ready', methods=['GET'])
        def ready_check():
            """Readiness check endpoint"""
            # Override in subclasses for service-specific checks
            return jsonify({'ready': True}), 200
    
    def error_handler(self, func):
        """Decorator for error handling"""
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Error: {e}")
                return jsonify({'error': str(e)}), 500
        return wrapper
    
    def run(self):
        """Start the service"""
        logger.info(f"🚀 Starting {self.service_name}")
        logger.info(f"Config: {self.config}")
        
        self.app.run(
            host='0.0.0.0',
            port=self.config['port'],
            debug=self.config['debug'],
            threaded=True
        )
