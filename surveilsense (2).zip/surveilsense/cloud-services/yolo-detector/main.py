import sys
import os
# import torch
# import gc
from flask import request, jsonify

# Adjust path to import base_service
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from base_service import BaseService
except ImportError:
    # Fallback for when running from root
    from cloud_services.base_service import BaseService

# Mock model class for independent testing
class MockYOLO:
    def predict(self, batch, conf=0.5):
        # Return mock results
        return [[{'class': 0, 'confidence': 0.9, 'box': [10, 10, 100, 100]}] for _ in batch]

service = BaseService('yolo-detector')
model = MockYOLO()

def predict_batch(model, frames, batch_size=4):
    """Batch inference with memory management"""
    results = []
    
    for i in range(0, len(frames), batch_size):
        batch = frames[i:i+batch_size]
        
        # Predict
        # with torch.no_grad():  # Disable gradient computation
        batch_results = model.predict(batch, conf=0.5)
        
        results.extend(batch_results)
        
        # Cleanup
        # torch.cuda.empty_cache()
        # gc.collect()
    
    return results

@service.app.route('/detect', methods=['POST'])
@service.error_handler
def detect():
    data = request.json
    # Assume data contains 'frames' or single 'frame'
    # Simplified for the framework skeleton
    frames = [data.get('frame', [])] 
    
    # In a real app we'd decode base64 frames here
    
    results = predict_batch(model, frames)
    return jsonify({'results': results})

if __name__ == '__main__':
    service.run()
