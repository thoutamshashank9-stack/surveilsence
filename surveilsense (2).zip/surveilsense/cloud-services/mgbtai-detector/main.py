import sys
import os
from flask import request, jsonify

# Adjust path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from base_service import BaseService
except ImportError:
    from cloud_services.base_service import BaseService

service = BaseService('mgbtai-detector')

@service.app.route('/detect', methods=['POST'])
@service.error_handler
def detect():
    # Mock detection
    return jsonify({'results': [{'type': 'mgbtai', 'anomaly': False}]})

if __name__ == '__main__':
    service.run()
