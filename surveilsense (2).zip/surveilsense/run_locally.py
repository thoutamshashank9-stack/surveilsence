import subprocess
import os
import time
import sys
import threading

# specific ports for local testing
PORTS = {
    'yolo-detector': 8081,
    'mgbtai-detector': 8082,
    'deepsad-detector': 8083,
    'ensemble-fusion': 8084,
    'alert-manager': 8085,
    'frame-capture': 8086
}

def start_service(name, port):
    print(f"🚀 Starting {name} on port {port}...")
    env = os.environ.copy()
    env['PORT'] = str(port)
    env['GCP_PROJECT_ID'] = 'mock-project'
    
    # Path to main.py
    script_path = os.path.join('cloud-services', name, 'main.py')
    
    # Run in subprocess
    try:
        proc = subprocess.Popen(
            [sys.executable, script_path],
            env=env,
            cwd=os.getcwd(), # running from root
            stdout=None,
            stderr=None
        )
        return proc
    except Exception as e:
        print(f"Failed to start {name}: {e}")
        return None

def main():
    print("🔧 Setting up local test environment...")
    
    procs = []
    
    try:
        # Start all services
        for name, port in PORTS.items():
            proc = start_service(name, port)
            if proc:
                procs.append((name, proc))
                time.sleep(1) # Give it a moment
        
        print("\n✅ All services started locally.")
        print("You can send requests to localhost:<port>")
        print("Press Ctrl+C to stop.\n")
        
        # Keep alive
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n🛑 Stopping services...")
    finally:
        for name, proc in procs:
            print(f"Terminating {name}...")
            proc.terminate()
            
if __name__ == "__main__":
    main()
