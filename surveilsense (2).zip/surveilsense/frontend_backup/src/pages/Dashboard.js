import React, { useEffect, useState } from 'react';
// import io from 'socket.io-client'; // Commented out to avoid dependency verify error in skeleton

const Dashboard = () => {
    const [detections, setDetections] = useState([]);
    const [status, setStatus] = useState('Disconnected');

    useEffect(() => {
        // WebSocket logic from Bug #12
        /*
        const socket = io('http://localhost:8080', {
            reconnection: true,
            reconnectionDelay: 1000,
            reconnectionDelayMax: 5000,
            reconnectionAttempts: 5
        });

        socket.on('connect', () => {
            setStatus('Connected');
        });

        socket.on('detection', (detection) => {
            // Update dashboard immediately
            setDetections(prev => [detection, ...prev].slice(0, 50));
        });

        socket.on('disconnect', () => {
            setStatus('Disconnected');
            console.warn('WebSocket disconnected');
        });

        return () => socket.disconnect();
        */
        console.log("Dashboard loaded. WebSocket implementation pending backend support.");
    }, []);

    return (
        <div className="dashboard">
            <h1>SurveilSense Dashboard</h1>
            <div className="status">Status: {status}</div>
            <div className="detections">
                {detections.map((det, idx) => (
                    <div key={idx} className="detection-card">
                        <p>Camera: {det.camera_id}</p>
                        <p>Type: {det.class}</p>
                        <p>Time: {det.timestamp}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Dashboard;
