#!/bin/bash
set -e

echo "🚀 SURVEILSENSE DEPLOYMENT (BUG-FREE)"
echo "===================================="

PROJECT_ID="${GOOGLE_CLOUD_PROJECT:-surveilsense-prod}"
REGION="${GOOGLE_CLOUD_REGION:-us-central1}"
PORT=8080

# Check required env vars
if [ -z "$PROJECT_ID" ]; then
    echo "❌ Set GOOGLE_CLOUD_PROJECT first"
    exit 1
fi

gcloud config set project $PROJECT_ID

# 1. Train models (sequential, with locks)
echo "🤖 Training models (with file locks)..."

# MGBTAI Training
python models/train_with_locks.py --model mgbtai \
    --output-dir=./models/weights \
    --lock-file=/tmp/mgbtai.lock &
MGBTAI_PID=$!

# Wait for MGBTAI to complete before starting DeepSAD
wait $MGBTAI_PID
echo "✅ MGBTAI training complete"

# DeepSAD Training
python models/train_with_locks.py --model deepsad \
    --output-dir=./models/weights \
    --lock-file=/tmp/deepsad.lock &
DEEPSAD_PID=$!

wait $DEEPSAD_PID
echo "✅ DeepSAD training complete"

# 2. Build and deploy services (with proper env vars)
echo "📦 Building and deploying services..."

SERVICES=(
    "yolo-detector"
    "mgbtai-detector"
    "deepsad-detector"
    "ensemble-fusion"
    "alert-manager"
    "frame-capture"
)

for service in "${SERVICES[@]}"; do
    echo ""
    echo "📍 Deploying $service..."
    
    service_dir="cloud-services/$service"
    
    # Build image
    gcloud builds submit $service_dir \
        --tag=gcr.io/${PROJECT_ID}/${service}:latest \
        --timeout=600s
    
    # Deploy with proper env vars (set at runtime, not build time)
    gcloud run deploy $service \
        --image=gcr.io/${PROJECT_ID}/${service}:latest \
        --region=$REGION \
        --platform=managed \
        --memory=4Gi \
        --cpu=2 \
        --port=$PORT \
        --timeout=120 \
        --max-instances=10 \
        --min-instances=1 \
        --set-env-vars="GCP_PROJECT_ID=${PROJECT_ID},GOOGLE_CLOUD_REGION=${REGION},PORT=${PORT}" \
        --service-account="surveilsense-sa@${PROJECT_ID}.iam.gserviceaccount.com" \
        --allow-unauthenticated \
        --ingress=all \
        --no-gen2
    
    echo "✅ $service deployed"
done

# 3. Deploy React frontend
echo ""
echo "🎨 Deploying React frontend..."

cd frontend
npm install
npm run build

# Deploy to Firebase Hosting
firebase deploy --project $PROJECT_ID

cd ..
echo "✅ Frontend deployed"

# 4. Enable Cloud Monitoring
echo ""
echo "📊 Setting up monitoring..."

# Create custom metrics
gcloud monitoring metrics-descriptors create \
    --display-name="SurveilSense Detection Latency" \
    --metric-kind=GAUGE \
    --value-type=DOUBLE \
    --unit=ms \
    2>/dev/null || echo "ℹ️  Metric already exists"

echo "✅ Monitoring configured"

# 5. Summary
echo ""
echo "✅ DEPLOYMENT COMPLETE!"
echo "========================"
echo ""
echo "Services deployed:"
for service in "${SERVICES[@]}"; do
    URL=$(gcloud run services describe $service --region=$REGION --format='value(status.url)' 2>/dev/null || echo "pending")
    echo "  • $service: $URL"
done
echo ""
echo "Dashboard: https://surveilsense-prod.web.app"
echo "Monitoring: https://console.cloud.google.com/monitoring"
echo ""
echo "Next: Run: bash deployment/verify-deployment.sh"
