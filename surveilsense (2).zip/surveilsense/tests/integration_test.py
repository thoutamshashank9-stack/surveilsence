import requests
import json
import time
import sys
import base64
import os

# Configuration matches run_locally.py
PORTS = {
    'yolo-detector': 8081,
    'mgbtai-detector': 8082,
    'deepsad-detector': 8083,
    'ensemble-fusion': 8084,
    'alert-manager': 8085,
    'frame-capture': 8086
}

BASE_URL = "http://localhost"

def test_health_checks():
    print("\n🩺 Testing Health Checks...")
    all_passed = True
    for name, port in PORTS.items():
        try:
            url = f"{BASE_URL}:{port}/health"
            response = requests.get(url, timeout=2)
            if response.status_code == 200:
                print(f"✅ {name}: OK")
            else:
                print(f"❌ {name}: Failed ({response.status_code})")
                all_passed = False
        except requests.exceptions.ConnectionError:
            print(f"❌ {name}: Connection Refused (Is it running?)")
            all_passed = False
    return all_passed

def test_yolo_flow():
    print("\n👁️ Testing YOLO Detection Flow...")
    url = f"{BASE_URL}:{PORTS['yolo-detector']}/detect"
    
    # Mock frame data
    payload = {
        "frame": "mock_base64_string",
        "camera_id": "cam_01",
        "timestamp": time.time()
    }
    
    try:
        response = requests.post(url, json=payload, timeout=5)
        if response.status_code == 200:
            data = response.json()
            if 'results' in data and isinstance(data['results'], list):
                print(f"✅ YOLO Response valid: {len(data['results'])} detections")
                return True
            else:
                print(f"❌ YOLO Invalid format: {data}")
        else:
            print(f"❌ YOLO Error {response.status_code}: {response.text}")
    except Exception as e:
        print(f"❌ YOLO Exception: {e}")
    return False

def test_alert_deduplication():
    print("\n🚨 Testing Alert Deduplication...")
    url = f"{BASE_URL}:{PORTS['alert-manager']}/process_alert"
    
    # Detection ID '123' for 'cam_01'
    payload = {
        "detections": [{"id": "123", "class": "person", "confidence": 0.9}],
        "camera_id": "cam_01"
    }
    
    try:
        # First call - should alert
        resp1 = requests.post(url, json=payload)
        data1 = resp1.json()
        
        # Second call immediately - should be deduplicated (not sent)
        resp2 = requests.post(url, json=payload)
        data2 = resp2.json()
        
        print(f"  Call 1: {data1.get('sent')} sent")
        print(f"  Call 2: {data2.get('sent')} sent")
        
        if data1.get('sent') == 1 and data2.get('sent') == 0:
            print("✅ Deduplication working correctly")
            return True
        else:
            print("❌ Deduplication failed")
            return False
            
    except Exception as e:
        print(f"❌ Alert Manager Exception: {e}")
    return False

def test_frame_buffer():
    print("\n📹 Testing Frame Capture Buffer...")
    url = f"{BASE_URL}:{PORTS['frame-capture']}/capture"
    
    try:
        # Send 35 frames (buffer size is 30)
        for i in range(35):
            requests.post(url, json={"frame": f"frame_{i}"})
            
        # Check status
        resp = requests.post(url, json={"frame": "frame_last"})
        data = resp.json()
        
        buffer_size = data.get('buffer_size')
        print(f"  Buffer Size: {buffer_size}")
        
        if buffer_size == 30:
            print("✅ Buffer limit respected (max 30)")
            return True
        else:
            print(f"❌ Buffer overflow or underflow: {buffer_size}")
            return False
            
    except Exception as e:
        print(f"❌ Frame Capture Exception: {e}")
    return False

def main():
    print("🚀 STARTED INTEGRATION TESTS")
    
    # Allow services to warm up
    time.sleep(2)
    
    health_ok = test_health_checks()
    if not health_ok:
        print("\n❌ CRITICAL: Health checks failed. Aborting logic tests.")
        sys.exit(1)
        
    yolo_ok = test_yolo_flow()
    alert_ok = test_alert_deduplication()
    buffer_ok = test_frame_buffer()
    
    print("\n" + "="*30)
    if health_ok and yolo_ok and alert_ok and buffer_ok:
        print("✅ ALL TESTS PASSED. SYSTEM IS STABLE.")
        sys.exit(0)
    else:
        print("⚠️ SOME TESTS FAILED. CHECK LOGS ABOVE.")
        sys.exit(1)

if __name__ == "__main__":
    main()
