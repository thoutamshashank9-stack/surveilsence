import numpy as np
import torch

def compute_embeddings(frame):
    """
    Mock implementation of embedding computation.
    In a real scenario, this would use a pre-trained model (e.g., ResNet).
    """
    # Simulate embedding extraction
    # Return a random vector for testing purposes
    return np.random.randn(128).astype(np.float32)

def extract_features_stable(frame):
    """Extract and normalize features safely"""
    features = compute_embeddings(frame)
    
    # Clip extreme values
    features = np.clip(features, -100, 100)
    
    # Normalize to [0, 1]
    features = (features - features.min()) / (features.max() - features.min() + 1e-8)
    
    # Check for NaN/Inf
    if np.any(np.isnan(features)) or np.any(np.isinf(features)):
        features = np.zeros_like(features)  # Return zeros if invalid
    
    return features
