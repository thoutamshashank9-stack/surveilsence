import cv2
import numpy as np

class FramePreprocessor:
    """Ensure identical preprocessing in train and serve"""
    
    NORMALIZATION_MEAN = np.array([0.485, 0.456, 0.406])
    NORMALIZATION_STD = np.array([0.229, 0.224, 0.225])
    TARGET_SIZE = (640, 640)
    
    @staticmethod
    def preprocess(frame):
        """Apply consistent preprocessing"""
        # Resize
        frame = cv2.resize(frame, FramePreprocessor.TARGET_SIZE)
        
        # Convert to float
        frame = frame.astype('float32')
        
        # Normalize pixel values
        frame = frame / 255.0
        
        # Apply ImageNet normalization
        frame = (frame - FramePreprocessor.NORMALIZATION_MEAN) / FramePreprocessor.NORMALIZATION_STD
        
        return frame
