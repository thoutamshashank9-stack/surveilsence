#!/usr/bin/env python3
"""
Training script with proper file locking and error handling.
Prevents race conditions when running multiple training jobs.
"""

import os
import sys
import argparse
import fcntl
import time
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def acquire_lock(lock_file_path):
    """Acquire exclusive lock on training"""
    lock_dir = os.path.dirname(lock_file_path)
    Path(lock_dir).mkdir(parents=True, exist_ok=True)
    
    lock_file = open(lock_file_path, 'w')
    try:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        logger.info(f"✅ Acquired lock: {lock_file_path}")
        return lock_file
    except BlockingIOError:
        logger.error(f"❌ Another training job is running (lock exists)")
        sys.exit(1)

def release_lock(lock_file):
    """Release lock on training"""
    try:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
        lock_file.close()
        logger.info("✅ Lock released")
    except Exception as e:
        logger.error(f"Error releasing lock: {e}")

def train_model(model_name, output_dir, lock_file):
    """Train model with locked output"""
    try:
        logger.info(f"🤖 Starting training for {model_name}...")
        
        # Import training module
        if model_name == "mgbtai":
            # from models.mgbtai_detector import train_mgbtai
            # train_function = train_mgbtai
            pass # Mocked for framework build
            train_function = lambda output_dir, batch_size, epochs: "mock_model"
        elif model_name == "deepsad":
            # from models.deepsad_detector import train_deepsad
            # train_function = train_deepsad
            pass # Mocked
            train_function = lambda output_dir, batch_size, epochs: "mock_model"
        else:
            raise ValueError(f"Unknown model: {model_name}")
        
        # Train
        model = train_function(
            output_dir=output_dir,
            batch_size=32,
            epochs=10
        )
        
        # Save with timestamp
        timestamp = int(time.time())
        output_path = os.path.join(
            output_dir,
            f"{model_name}_weights_{timestamp}.pkl"
        )
        
        # Ensure output directory exists
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        # Save model
        import pickle
        with open(output_path, 'wb') as f:
            pickle.dump(model, f)
        
        logger.info(f"✅ Model saved: {output_path}")
        return True
    
    except Exception as e:
        logger.error(f"❌ Training failed: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(
        description="Train ML models with exclusive locking"
    )
    parser.add_argument(
        '--model',
        choices=['mgbtai', 'deepsad'],
        required=True,
        help='Which model to train'
    )
    parser.add_argument(
        '--output-dir',
        default='./models/weights',
        help='Output directory for weights'
    )
    parser.add_argument(
        '--lock-file',
        help='Lock file path (default: /tmp/{model}.lock)'
    )
    
    args = parser.parse_args()
    
    # Determine lock file
    lock_file_path = args.lock_file or f"/tmp/{args.model}.lock"
    
    # Acquire lock
    lock_file = acquire_lock(lock_file_path)
    
    try:
        # Train model
        success = train_model(
            args.model,
            args.output_dir,
            lock_file
        )
        
        if success:
            logger.info(f"✅ Training complete: {args.model}")
            sys.exit(0)
        else:
            logger.error(f"❌ Training failed: {args.model}")
            sys.exit(1)
    
    finally:
        # Always release lock
        release_lock(lock_file)

if __name__ == '__main__':
    main()
